# ☕ Starbucks Capstone Project

## 📌 Project Overview
This project analyzes the Starbucks Rewards dataset to understand customer behavior and predict offer responses using Machine Learning.

The project includes data preprocessing, exploratory data analysis (EDA), feature engineering, model building, and performance evaluation.

---

## 🎯 Objectives
- Analyze customer demographics.
- Explore customer transaction behavior.
- Study different offer types.
- Predict whether a customer will respond to an offer.
- Compare machine learning model performance.

---

## 📂 Dataset
The project uses the Starbucks Capstone Challenge dataset which contains:

- portfolio.csv
- profile.csv
- transcript.csv

---

## 🛠 Technologies Used

- Python
- Jupyter Notebook
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn

---

## 📊 Project Steps

1. Data Loading
2. Data Cleaning
3. Data Preprocessing
4. Exploratory Data Analysis (EDA)
5. Feature Engineering
6. Model Training
7. Model Evaluation
8. Results & Conclusions

---

## 📈 Machine Learning

The project applies machine learning techniques to predict customer responses based on historical behavior.

---

## 📁 Repository Structure

```
Starbucks-Capstone/
│
├── project.ipynb
├── portfolio.csv
├── profile.csv
├── transcript.csv
├── Graduation Project.docx
├── Presentation.pptx
└── README.md
```

---

## 🚀 How to Run

1. Clone the repository

```bash
git clone https://github.com/hazem-abdelaal/Starbucks-Capstone.git
```

2. Install the required libraries

```bash
pip install pandas numpy matplotlib seaborn scikit-learn
```

3. Open

```
project.ipynb
```

using Jupyter Notebook.

---

## 👨‍💻 Author

**Hazem Abdelaal**

GitHub:
https://github.com/hazem-abdelaal
