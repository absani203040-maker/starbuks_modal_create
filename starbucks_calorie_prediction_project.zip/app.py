import os
import joblib
import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="Starbucks Calories Predictor",
    page_icon="☕",
    layout="centered"
)

st.title("☕ Starbucks Calories Predictor")
st.write("Enter beverage information to estimate its calories.")

MODEL_PATH = os.path.join(os.path.dirname(__file__), "starbucks_calorie_model.pkl")

@st.cache_resource
def load_package(path):
    return joblib.load(path)

if not os.path.isfile(MODEL_PATH):
    st.error("Model file not found. Keep starbucks_calorie_model.pkl in the same folder as app.py.")
    st.stop()

try:
    package = load_package(MODEL_PATH)
    model = package["model"]
    features = package["features"]
    training_data = package["training_data"]
except Exception as error:
    st.error(f"Unable to load model: {error}")
    st.stop()

st.subheader("Beverage Information")
user_values = {}

with st.form("calorie_prediction_form"):
    for feature in features:
        column = training_data[feature]

        if pd.api.types.is_numeric_dtype(column):
            numeric_column = pd.to_numeric(column, errors="coerce")
            default_value = numeric_column.median()
            if pd.isna(default_value):
                default_value = 0.0

            user_values[feature] = st.number_input(
                label=str(feature),
                value=float(default_value),
                step=1.0,
                key=f"field_{feature}"
            )
        else:
            options = column.dropna().astype(str).unique().tolist()
            if options:
                user_values[feature] = st.selectbox(
                    label=str(feature),
                    options=options,
                    key=f"field_{feature}"
                )
            else:
                user_values[feature] = ""

    submitted = st.form_submit_button("Predict Calories")

if submitted:
    try:
        input_df = pd.DataFrame([user_values], columns=features)

        for feature in features:
            if pd.api.types.is_numeric_dtype(training_data[feature]):
                input_df[feature] = pd.to_numeric(input_df[feature], errors="coerce")

        prediction = float(model.predict(input_df)[0])
        st.success(f"Estimated Calories: {prediction:.1f} kcal")
        st.caption("This is a machine-learning estimate, not an official Starbucks nutrition value.")
    except Exception as error:
        st.error(f"Prediction failed: {error}")

st.divider()
st.caption("Starbucks Calories Prediction | Machine Learning Project")
