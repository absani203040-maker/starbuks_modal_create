import os
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score

DATA_PATH = "starbucks.csv"
OUTPUT_PATH = "starbucks_calorie_model.pkl"

df = pd.read_csv(DATA_PATH)
df.columns = df.columns.str.strip()
df["Calories"] = pd.to_numeric(df["Calories"], errors="coerce")
df = df.dropna(subset=["Calories"]).copy()

X = df.drop(columns=["Calories"])
y = df["Calories"]
X = X[[c for c in X.columns if X[c].nunique(dropna=True) > 1]].copy()

numeric_features = X.select_dtypes(include=["number"]).columns.tolist()
categorical_features = X.select_dtypes(exclude=["number"]).columns.tolist()

numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median"))
])
categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer([
    ("numeric", numeric_pipeline, numeric_features),
    ("categorical", categorical_pipeline, categorical_features)
])

model = Pipeline([
    ("preprocessor", preprocessor),
    ("regressor", RandomForestRegressor(
        n_estimators=300, random_state=42, n_jobs=-1
    ))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("MAE:", round(mean_absolute_error(y_test, predictions), 2))
print("R2 Score:", round(r2_score(y_test, predictions), 3))

package = {
    "model": model,
    "features": X.columns.tolist(),
    "training_data": X.copy(),
    "target": "Calories",
    "metrics": {
        "mae": float(mean_absolute_error(y_test, predictions)),
        "r2": float(r2_score(y_test, predictions))
    },
    "numeric_features": numeric_features,
    "categorical_features": categorical_features
}
joblib.dump(package, OUTPUT_PATH)
print("Saved model:", os.path.abspath(OUTPUT_PATH))
