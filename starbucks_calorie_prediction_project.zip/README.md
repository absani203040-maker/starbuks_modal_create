# Starbucks Calories Prediction

Files:
- `starbucks_calorie_model.pkl`: trained model package
- `app.py`: Streamlit prediction app
- `requirements.txt`: app dependencies
- `starbucks.csv`: source dataset used for training
- `train_model.py`: script to retrain the model

## Run locally
1. Install Python.
2. Run `pip install -r requirements.txt`
3. Run `streamlit run app.py`

The model was evaluated on a held-out 20% test split. In this run:
- MAE: 14.77 calories
- R²: 0.946

These are test-set metrics, not a guarantee of accuracy for every drink.
